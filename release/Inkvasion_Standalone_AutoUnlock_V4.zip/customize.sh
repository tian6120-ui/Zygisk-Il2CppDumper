#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"
AZ_ID="azv07_scriptcore_game"
TMP="$MODPATH/.install_tmp"

ui_print "********************************************"
ui_print " Inkvasion Standalone Auto Unlock V4"
ui_print " OFFLINE installer - runtime discovery"
ui_print " target: $PKG"
ui_print " host ABI: $ARCH"
ui_print "********************************************"

rm -rf "$MODPATH/zygisk" "$TMP"
rm -f "$MODPATH"/payload.* "$MODPATH"/hostui.*
mkdir -p "$MODPATH/zygisk" "$TMP"

case "$ARCH" in
  x64|x86_64|arm64|arm64-v8a|aarch64) ;;
  *) abort "Unsupported host ABI: $ARCH (supported: x64, arm64)" ;;
esac

module_id_of() {
  P="$1"
  [ -f "$P/module.prop" ] || return 1
  sed -n 's/^id=//p' "$P/module.prop" 2>/dev/null | head -n 1 | tr -d '\r'
}

find_az_source() {
  for D in     /data/adb/modules/$AZ_ID     /data/adb/modules_update/$AZ_ID     /data/adb/ksu/modules/$AZ_ID     /data/adb/ksu/modules_update/$AZ_ID
  do
    [ -d "$D" ] || continue
    ID="$(module_id_of "$D")"
    [ "$ID" = "$AZ_ID" ] && { echo "$D"; return 0; }
  done

  for P in $(find /data/adb -maxdepth 6 -type f -name module.prop 2>/dev/null); do
    D="$(dirname "$P")"
    [ "$D" = "$MODPATH" ] && continue
    ID="$(sed -n 's/^id=//p' "$P" 2>/dev/null | head -n 1 | tr -d '\r')"
    [ "$ID" = "$AZ_ID" ] && { echo "$D"; return 0; }
  done
  return 1
}

print_scan_diag() {
  ui_print "- AZ module discovery diagnostics:"
  N=0
  for P in $(find /data/adb -maxdepth 5 -type f -name module.prop 2>/dev/null); do
    D="$(dirname "$P")"
    ID="$(sed -n 's/^id=//p' "$P" 2>/dev/null | head -n 1 | tr -d '\r')"
    [ -n "$ID" ] || continue
    ui_print "  $D -> id=$ID"
    N=$((N+1))
    [ "$N" -ge 20 ] && break
  done
  [ "$N" -eq 0 ] && ui_print "  no module.prop files visible under /data/adb"
}

AZSRC="$(find_az_source 2>/dev/null)"
if [ -z "$AZSRC" ]; then
  print_scan_diag
  abort "AZ module id=$AZ_ID not visible to installer"
fi

ui_print "- Found AZ module:"
ui_print "  $AZSRC"

find_one() {
  BASE="$1"; shift
  for PAT in "$@"; do
    R="$(find "$BASE" -type f -name "$PAT" 2>/dev/null | head -n 1)"
    [ -n "$R" ] && { echo "$R"; return 0; }
  done
  return 1
}

CORE64="$(find_one "$AZSRC" 'libAZCore07_arm64.so' 'payload.arm64' '*AZCore*arm64*.so')"
LDR64="$(find "$AZSRC" -type f \( -path '*/zygisk/arm64-v8a.so' -o -name 'libAZLoader07_arm64.so' \) 2>/dev/null | head -n 1)"
LDRX64="$(find "$AZSRC" -type f \( -path '*/zygisk/x86_64.so' -o -name 'libAZLoader07_x86_64.so' \) 2>/dev/null | head -n 1)"
COREX64="$(find_one "$AZSRC" 'libAZCore07_x86_64.so' 'payload.x86_64' '*AZCore*x86_64*.so')"
HOSTX64="$(find_one "$AZSRC" 'hostui.x86_64' 'libAZHostUI07_x86_64.so' '*HostUI*x86_64*.so')"

ui_print "- Runtime discovery:"
if [ -n "$CORE64" ]; then ui_print "  arm64 core: $CORE64"; else ui_print "  arm64 core: MISSING"; fi
if [ -n "$LDR64" ]; then ui_print "  arm64 loader: $LDR64"; else ui_print "  arm64 loader: MISSING"; fi
if [ -n "$LDRX64" ]; then ui_print "  x86_64 loader: $LDRX64"; else ui_print "  x86_64 loader: MISSING"; fi

if [ -z "$CORE64" ]; then
  ui_print "- Files visible in AZ root:"
  ls -la "$AZSRC" 2>/dev/null | head -n 60
  abort "AZ arm64 Core not found in discovered module"
fi

cp -f "$CORE64" "$MODPATH/payload.arm64" || abort "Failed copying arm64 Core"
[ -z "$LDR64" ] || cp -f "$LDR64" "$MODPATH/zygisk/arm64-v8a.so" || abort "Failed copying arm64 Loader"
[ -z "$LDRX64" ] || cp -f "$LDRX64" "$MODPATH/zygisk/x86_64.so" || abort "Failed copying x86_64 Loader"
[ -z "$COREX64" ] || cp -f "$COREX64" "$MODPATH/payload.x86_64" 2>/dev/null
[ -z "$HOSTX64" ] || cp -f "$HOSTX64" "$MODPATH/hostui.x86_64" 2>/dev/null

case "$ARCH" in
  x64|x86_64)
    [ -f "$MODPATH/zygisk/x86_64.so" ] || abort "x86_64 Zygisk Loader not found in AZ module"
    [ -f "$MODPATH/payload.arm64" ] || abort "arm64 guest Core missing after copy"
    ui_print "- Runtime ready: x86_64 host Loader + arm64 guest Core"
    ;;
  *)
    [ -f "$MODPATH/zygisk/arm64-v8a.so" ] || abort "arm64 Zygisk Loader not found in AZ module"
    [ -f "$MODPATH/payload.arm64" ] || abort "arm64 Core missing after copy"
    ui_print "- Runtime ready: native arm64 Loader + Core"
    ;;
esac

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"
printf '%s\n' "$AZSRC" > "$MODPATH/az_source_path.txt"

if [ -f "$AZSRC/tooltarget.txt" ] && grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
  cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
  awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$TMP/tooltarget.new"
  cat "$TMP/tooltarget.new" > "$AZSRC/tooltarget.txt"
  : > "$MODPATH/.az_target_removed"
  ui_print "- Removed Inkvasion from main AZ target list only"
fi

for P in "$MODPATH"/payload.*; do
  [ -f "$P" ] || continue
  OFF="$(grep -aob -m1 'AZ_TRANSLATED_GUEST' "$P" 2>/dev/null | cut -d: -f1)"
  case "$OFF" in
    ''|*[!0-9]*) ;;
    *) printf 'PATH\000' | dd of="$P" bs=1 seek="$OFF" conv=notrunc 2>/dev/null ;;
  esac
done

chmod 0755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH"/payload.* "$MODPATH"/hostui.* 2>/dev/null
chmod 0644 "$MODPATH"/zygisk/*.so 2>/dev/null
rm -rf "$TMP"

ui_print "- Offline runtime discovery/copy complete"
ui_print "- No downloads were used"
ui_print "- Reboot required"
ui_print "- Inkvasion will auto-supplement after launch"
