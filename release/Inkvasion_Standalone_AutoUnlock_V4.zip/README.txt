Inkvasion Standalone Auto Unlock V4

Fixes V3 runtime discovery.
V4 locates the installed AZ module by module.prop:
  id=azv07_scriptcore_game

Then recursively locates the actual Loader/Core files.
It checks standard Magisk/KernelSU module roots and also scans /data/adb for the exact module id.

No installer networking.
If discovery fails, installer prints visible module IDs and runtime paths.

Target: com.chillyroom.inkvasion.gp
