#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"
AZ_ID="azv07_scriptcore_game"
TMP="$MODPATH/.install_tmp"

ui_print "********************************************"
ui_print " Inkvasion Standalone Auto Unlock V6"
ui_print " HF7 Glass4 runtime protocol"
ui_print " OFFLINE - no network"
ui_print " target: $PKG"
ui_print " host ABI: $ARCH"
ui_print "********************************************"

rm -rf "$MODPATH/zygisk" "$TMP"
rm -f "$MODPATH"/libAZGlass4_*.so
mkdir -p "$MODPATH/zygisk" "$TMP"

case "$ARCH" in
  x64|x86_64|arm64|arm64-v8a|aarch64) ;;
  *) abort "Unsupported host ABI: $ARCH (supported: x64, arm64)" ;;
esac

module_id_of() {
  P="$1"
  [ -f "$P/module.prop" ] || return 1
  sed -n 's/^id=//p' "$P/module.prop" 2>/dev/null | head -n 1 | tr -d '\r'
}

find_az_source() {
  for D in     /data/adb/modules/$AZ_ID     /data/adb/modules_update/$AZ_ID     /data/adb/ksu/modules/$AZ_ID     /data/adb/ksu/modules_update/$AZ_ID
  do
    [ -d "$D" ] || continue
    ID="$(module_id_of "$D")"
    [ "$ID" = "$AZ_ID" ] && { echo "$D"; return 0; }
  done
  for P in $(find /data/adb -maxdepth 6 -type f -name module.prop 2>/dev/null); do
    D="$(dirname "$P")"
    [ "$D" = "$MODPATH" ] && continue
    ID="$(sed -n 's/^id=//p' "$P" 2>/dev/null | head -n 1 | tr -d '\r')"
    [ "$ID" = "$AZ_ID" ] && { echo "$D"; return 0; }
  done
  return 1
}

AZSRC="$(find_az_source 2>/dev/null)"
[ -n "$AZSRC" ] || abort "AZ module id=$AZ_ID not visible to installer"

ui_print "- Found HF7 AZ module:"
ui_print "  $AZSRC"

LDRX64="$(find "$AZSRC" -type f -path '*/zygisk/x86_64.so' 2>/dev/null | head -n 1)"
LDR64="$(find "$AZSRC" -type f -path '*/zygisk/arm64-v8a.so' 2>/dev/null | head -n 1)"
GLASS64="$(find "$AZSRC" -maxdepth 3 -type f -name 'libAZGlass4_arm64.so' 2>/dev/null | head -n 1)"
GLASSX64="$(find "$AZSRC" -maxdepth 3 -type f -name 'libAZGlass4_x86_64.so' 2>/dev/null | head -n 1)"
GLASS32="$(find "$AZSRC" -maxdepth 3 -type f -name 'libAZGlass4_arm32.so' 2>/dev/null | head -n 1)"
GLASSX86="$(find "$AZSRC" -maxdepth 3 -type f -name 'libAZGlass4_x86.so' 2>/dev/null | head -n 1)"

ui_print "- HF7 runtime discovery:"
[ -n "$LDRX64" ] && ui_print "  x86_64 loader: $LDRX64" || ui_print "  x86_64 loader: MISSING"
[ -n "$LDR64" ] && ui_print "  arm64 loader: $LDR64" || ui_print "  arm64 loader: MISSING"
[ -n "$GLASS64" ] && ui_print "  arm64 payload: $GLASS64" || ui_print "  arm64 payload: MISSING"

[ -n "$GLASS64" ] || abort "HF7 libAZGlass4_arm64.so not found"

for F in "$AZSRC"/zygisk/*.so; do
  [ -f "$F" ] || continue
  cp -f "$F" "$MODPATH/zygisk/$(basename "$F")" || abort "Failed copying $(basename "$F")"
done

cp -f "$GLASS64" "$MODPATH/libAZGlass4_arm64.so" || abort "Failed copying arm64 Glass4 payload"
[ -z "$GLASSX64" ] || cp -f "$GLASSX64" "$MODPATH/libAZGlass4_x86_64.so"
[ -z "$GLASS32" ] || cp -f "$GLASS32" "$MODPATH/libAZGlass4_arm32.so"
[ -z "$GLASSX86" ] || cp -f "$GLASSX86" "$MODPATH/libAZGlass4_x86.so"

case "$ARCH" in
  x64|x86_64)
    [ -f "$MODPATH/zygisk/x86_64.so" ] || abort "HF7 x86_64 Zygisk Loader missing"
    [ -f "$MODPATH/libAZGlass4_arm64.so" ] || abort "HF7 arm64 Glass4 payload missing"
    ui_print "- Runtime ready: x86_64 HF7 Loader + libAZGlass4_arm64.so"
    ;;
  *)
    [ -f "$MODPATH/zygisk/arm64-v8a.so" ] || abort "HF7 arm64 Zygisk Loader missing"
    [ -f "$MODPATH/libAZGlass4_arm64.so" ] || abort "HF7 arm64 Glass4 payload missing"
    ui_print "- Runtime ready: native arm64 HF7 Loader + Glass4 payload"
    ;;
esac

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"
printf '%s\n' "$AZSRC" > "$MODPATH/az_source_path.txt"

# Avoid double injection by the original AZ module.
if [ -f "$AZSRC/tooltarget.txt" ] && grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
  cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
  awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$TMP/tooltarget.new"
  cat "$TMP/tooltarget.new" > "$AZSRC/tooltarget.txt"
  : > "$MODPATH/.az_target_removed"
  ui_print "- Removed Inkvasion from main AZ target list only"
fi

chmod 0755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH"/libAZGlass4_*.so 2>/dev/null
chmod 0644 "$MODPATH"/zygisk/*.so 2>/dev/null
rm -rf "$TMP"

ui_print "- HF7 runtime copied with original payload names"
ui_print "- No downloads were used"
ui_print "- Reboot required"
ui_print "- Inkvasion will auto-supplement via HF7 last.lua runner"
