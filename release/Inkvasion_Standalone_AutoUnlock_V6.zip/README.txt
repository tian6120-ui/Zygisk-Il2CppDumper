Inkvasion Standalone Auto Unlock V6

V6 fixes the automatic execution protocol.

HF7 AZ Runner expects:
  /data/user/0/<package>/files/AZTool/last.lua
and an EMPTY:
  script.req

V5 incorrectly copied inkvasion_autorun.lua under its own filename and wrote that filename into script.req.
That means the HF7 runner never executed the unlock payload.

V6:
  - copies the verified autorun payload to AZTool/last.lua
  - creates an empty AZTool/script.req trigger
  - waits for RESULT | PASS in script.out
  - records FATAL/retry status in inkvasion_service.log
  - retains the HF7 Glass4 runtime protocol from V5
  - no watchdog Lua loop
  - no HTTP/store/IAP/currency/server writes

Target:
  com.chillyroom.inkvasion.gp
