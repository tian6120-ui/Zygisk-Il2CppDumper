#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"
SCRIPT="$MODDIR/inkvasion_autorun.lua"
LOG="$MODDIR/inkvasion_service.log"
LAST_PID=""

logi(){ echo "$(date '+%F %T') $*" >> "$LOG"; }

find_base(){
  for B in /data/user/*/"$PKG" /data/data/"$PKG"; do
    [ -d "$B" ] || continue
    echo "$B"; return 0
  done
  return 1
}

tail_has_pass(){
  ROOT="$1"
  [ -f "$ROOT/script.out" ] || return 1
  tail -n 160 "$ROOT/script.out" 2>/dev/null | grep -Fq "[INKVASION AUTO ONE-SHOT V1] RESULT | PASS | ALL HERO + FIGHT + BUILD"
}

tail_has_fatal(){
  ROOT="$1"
  [ -f "$ROOT/script.out" ] || return 1
  tail -n 160 "$ROOT/script.out" 2>/dev/null | grep -Fq "[INKVASION AUTO ONE-SHOT V1] FATAL |"
}

trigger_process(){
  PID="$1"
  BASE=""
  N=0

  while [ "$N" -lt 120 ]; do
    [ ! -d "/proc/$PID" ] && return
    BASE="$(find_base 2>/dev/null)"
    [ -n "$BASE" ] && break
    sleep 1
    N=$((N+1))
  done

  [ -n "$BASE" ] || { logi "NO APP DATA pid=$PID"; return; }

  ROOT="$BASE/files/AZTool"
  UIDN="$(stat -c '%u' "$BASE" 2>/dev/null)"
  GIDN="$(stat -c '%g' "$BASE" 2>/dev/null)"

  N=0
  while [ "$N" -lt 150 ]; do
    [ ! -d "/proc/$PID" ] && return
    [ -f "$ROOT/agent.ready" ] && break
    sleep 1
    N=$((N+1))
  done

  [ -f "$ROOT/agent.ready" ] || {
    logi "AGENT TIMEOUT pid=$PID root=$ROOT"
    return
  }

  logi "AGENT READY pid=$PID root=$ROOT"

  # Let normal UserAssets + config masters finish loading first.
  sleep 8
  [ ! -d "/proc/$PID" ] && return

  ATTEMPT=1
  while [ "$ATTEMPT" -le 5 ]; do
    [ ! -d "/proc/$PID" ] && return

    # HF7 VERIFIED RUNNER PROTOCOL:
    #   1) payload must be AZTool/last.lua
    #   2) script.req is an EMPTY trigger marker
    cp -f "$SCRIPT" "$ROOT/last.lua" || {
      logi "COPY last.lua FAILED pid=$PID attempt=$ATTEMPT"
      return
    }

    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/last.lua" 2>/dev/null
    chmod 600 "$ROOT/last.lua" 2>/dev/null

    rm -f "$ROOT/script.status" "$ROOT/stop.req"
    : > "$ROOT/script.req"
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/script.req" 2>/dev/null
    chmod 600 "$ROOT/script.req" 2>/dev/null

    logi "TRIGGER last.lua pid=$PID attempt=$ATTEMPT"

    T=0
    while [ "$T" -lt 120 ]; do
      [ ! -d "/proc/$PID" ] && return

      if tail_has_pass "$ROOT"; then
        logi "PASS pid=$PID attempt=$ATTEMPT"
        return
      fi

      if tail_has_fatal "$ROOT"; then
        FATAL_LINE="$(tail -n 160 "$ROOT/script.out" 2>/dev/null | grep -F "[INKVASION AUTO ONE-SHOT V1] FATAL |" | tail -n 1)"
        logi "SCRIPT FATAL pid=$PID attempt=$ATTEMPT | $FATAL_LINE"
        break
      fi

      if [ -f "$ROOT/script.status" ]; then
        STATE="$(sed -n 's/^state=//p' "$ROOT/script.status" 2>/dev/null | head -n 1)"
        case "$STATE" in
          ERROR|STOPPED)
            logi "RUNNER state=$STATE pid=$PID attempt=$ATTEMPT"
            break
            ;;
          DONE)
            # DONE without PASS can happen if game assets were not ready yet.
            logi "RUNNER DONE WITHOUT PASS pid=$PID attempt=$ATTEMPT"
            break
            ;;
        esac
      fi

      sleep 1
      T=$((T+1))
    done

    ATTEMPT=$((ATTEMPT+1))
    [ "$ATTEMPT" -le 5 ] && sleep 10
  done

  logi "FAILED pid=$PID after retries"
}

: > "$LOG"
logi "SERVICE START | protocol=last.lua+empty-script.req"

while true; do
  PID="$(pidof "$PKG" 2>/dev/null | awk '{print $1}')"

  if [ -n "$PID" ]; then
    if [ "$PID" != "$LAST_PID" ]; then
      LAST_PID="$PID"
      logi "NEW PID $PID"
      trigger_process "$PID" &
    fi
  else
    LAST_PID=""
  fi

  sleep 2
done
