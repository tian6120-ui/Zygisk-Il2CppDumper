#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"
AZSRC="/data/adb/modules/azv07_scriptcore_game"
HIST_URL="https://nightly.link/tian6120-ui/Zygisk-Il2CppDumper/actions/artifacts/11227499534.zip"
TMP="$MODPATH/.bootstrap"

ui_print "***************************************"
ui_print " Inkvasion Standalone Auto Unlock V1"
ui_print " target: $PKG"
ui_print " arm64 only"
ui_print "***************************************"

case "$ARCH" in
  arm64|arm64-v8a|aarch64) ;;
  *) abort "Unsupported ABI: $ARCH (arm64 required)" ;;
esac

mkdir -p "$MODPATH/zygisk" "$TMP"

copy_current_az() {
  [ -f "$AZSRC/zygisk/arm64-v8a.so" ] || return 1
  [ -f "$AZSRC/libAZCore07_arm64.so" ] || return 1
  cp -f "$AZSRC/zygisk/arm64-v8a.so" "$MODPATH/zygisk/arm64-v8a.so" || return 1
  cp -f "$AZSRC/libAZCore07_arm64.so" "$MODPATH/payload.arm64" || return 1
  return 0
}

download_fallback() {
  rm -rf "$TMP/runtime"
  mkdir -p "$TMP/runtime"
  rm -f "$TMP/AZV07-arm64-v8a.zip"
  if command -v curl >/dev/null 2>&1; then
    curl -LfsS "$HIST_URL" -o "$TMP/AZV07-arm64-v8a.zip" || return 1
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$TMP/AZV07-arm64-v8a.zip" "$HIST_URL" || return 1
  elif command -v busybox >/dev/null 2>&1; then
    busybox wget -q -O "$TMP/AZV07-arm64-v8a.zip" "$HIST_URL" || return 1
  else
    return 1
  fi
  if command -v unzip >/dev/null 2>&1; then
    unzip -oq "$TMP/AZV07-arm64-v8a.zip" -d "$TMP/runtime" || return 1
  elif command -v busybox >/dev/null 2>&1; then
    busybox unzip -oq "$TMP/AZV07-arm64-v8a.zip" -d "$TMP/runtime" || return 1
  else
    return 1
  fi
  LDR="$(find "$TMP/runtime" -type f -name 'libAZLoader07.so' 2>/dev/null | head -n 1)"
  CORE="$(find "$TMP/runtime" -type f -name 'libAZCore07.so' 2>/dev/null | head -n 1)"
  [ -n "$LDR" ] || return 1
  [ -n "$CORE" ] || return 1
  cp -f "$LDR" "$MODPATH/zygisk/arm64-v8a.so" || return 1
  cp -f "$CORE" "$MODPATH/payload.arm64" || return 1
  return 0
}

if copy_current_az; then
  ui_print "- Runtime: copied current AZ/HF7 arm64 Loader + Core"
else
  ui_print "- Current AZ runtime not found; downloading verified historical arm64 artifact"
  download_fallback || abort "Unable to obtain arm64 runtime. Install current AZ once, then flash this module again."
  ui_print "- Runtime: fallback artifact installed"
fi

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"

if [ -f "$AZSRC/tooltarget.txt" ]; then
  if grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
    cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
    awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$TMP/tooltarget.new"
    cat "$TMP/tooltarget.new" > "$AZSRC/tooltarget.txt"
    ui_print "- Removed Inkvasion only from main AZ target list (backup kept)"
  fi
fi

OFF="$(grep -aob -m1 'AZ_TRANSLATED_GUEST' "$MODPATH/payload.arm64" 2>/dev/null | cut -d: -f1)"
case "$OFF" in
  ''|*[!0-9]*) ui_print "- UI suppression marker not found; runtime still usable" ;;
  *)
    printf 'PATH\000' | dd of="$MODPATH/payload.arm64" bs=1 seek="$OFF" conv=notrunc 2>/dev/null
    ui_print "- AZ UI suppressed; ScriptCore kept"
    ;;
esac

chmod 0755 "$MODPATH/service.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/payload.arm64" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH/zygisk/arm64-v8a.so"
rm -rf "$TMP"

ui_print "- Install complete"
ui_print "- Reboot required"
ui_print "- Inkvasion auto-supplements once per new game process"
