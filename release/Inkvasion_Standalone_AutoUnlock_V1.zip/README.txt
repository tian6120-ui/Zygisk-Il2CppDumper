Inkvasion Standalone Auto Unlock V1
Target: com.chillyroom.inkvasion.gp (arm64)

Install-time runtime source:
1. Prefer current /data/adb/modules/azv07_scriptcore_game arm64 Loader/Core.
2. Fallback to public historical GitHub Actions arm64 artifact 11227499534.

After install, this module owns its own copied runtime.
Inkvasion is removed only from the original AZ tooltarget list to prevent double injection.

Runtime behavior:
- one-shot per new Inkvasion process
- dynamic Hero/Fight/Building master
- skip existing entries
- new cards: level 1, exp 0
- no HTTP/store/IAP/currency/server ownership writes
- no Lua watchdog loop

Logs:
 /data/adb/modules/inkvasion_standalone_autounlock/inkvasion_service.log
 /data/user/0/com.chillyroom.inkvasion.gp/files/AZTool/script.out
 /data/user/0/com.chillyroom.inkvasion.gp/files/AZTool/script.status
