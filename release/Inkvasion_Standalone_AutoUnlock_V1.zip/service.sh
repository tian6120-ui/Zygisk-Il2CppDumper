#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"
SCRIPT="$MODDIR/inkvasion_autorun.lua"
LOG="$MODDIR/inkvasion_service.log"
LAST_PID=""

logi() {
  echo "$(date '+%F %T') $*" >> "$LOG"
}

trigger_process() {
  PID="$1"
  BASE="/data/user/0/$PKG"
  ROOT="$BASE/files/AZTool"

  N=0
  while [ "$N" -lt 60 ]; do
    [ ! -d "/proc/$PID" ] && return
    [ -d "$BASE/files" ] && break
    sleep 1
    N=$((N+1))
  done
  [ ! -d "/proc/$PID" ] && return
  sleep 10
  [ ! -d "/proc/$PID" ] && return

  UIDN="$(stat -c '%u' "$BASE" 2>/dev/null)"
  GIDN="$(stat -c '%g' "$BASE" 2>/dev/null)"
  mkdir -p "$ROOT"
  [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT" 2>/dev/null
  chmod 700 "$ROOT" 2>/dev/null

  cp -f "$SCRIPT" "$ROOT/inkvasion_autorun.lua" || return
  [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/inkvasion_autorun.lua" 2>/dev/null
  chmod 600 "$ROOT/inkvasion_autorun.lua" 2>/dev/null

  ATTEMPT=1
  while [ "$ATTEMPT" -le 5 ]; do
    [ ! -d "/proc/$PID" ] && return
    rm -f "$ROOT/script.status"
    printf '%s\n' "inkvasion_autorun.lua" > "$ROOT/script.req"
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/script.req" 2>/dev/null
    chmod 600 "$ROOT/script.req" 2>/dev/null
    logi "TRIGGER pid=$PID attempt=$ATTEMPT"

    T=0
    while [ "$T" -lt 90 ]; do
      [ ! -d "/proc/$PID" ] && return
      if [ -f "$ROOT/script.status" ]; then
        STATE="$(sed -n 's/^state=//p' "$ROOT/script.status" 2>/dev/null | head -n 1)"
        case "$STATE" in
          DONE) logi "PASS pid=$PID attempt=$ATTEMPT"; return ;;
          ERROR|STOPPED) logi "RETRY pid=$PID attempt=$ATTEMPT state=$STATE"; break ;;
        esac
      fi
      sleep 1
      T=$((T+1))
    done
    ATTEMPT=$((ATTEMPT+1))
    sleep 8
  done
  logi "FAILED pid=$PID after retries"
}

logi "SERVICE START"
while true; do
  PID="$(pidof "$PKG" 2>/dev/null | awk '{print $1}')"
  if [ -n "$PID" ]; then
    if [ "$PID" != "$LAST_PID" ]; then
      LAST_PID="$PID"
      logi "NEW PID $PID"
      trigger_process "$PID" &
    fi
  else
    LAST_PID=""
  fi
  sleep 2
done
