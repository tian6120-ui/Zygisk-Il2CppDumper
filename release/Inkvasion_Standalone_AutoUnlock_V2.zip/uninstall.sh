#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"

if [ -f "$MODDIR/.az_target_removed" ]; then
  AZSRC="$(cat "$MODDIR/az_source_path.txt" 2>/dev/null)"
  if [ ! -d "$AZSRC" ]; then
    [ -d /data/adb/modules/azv07_scriptcore_game ] && AZSRC=/data/adb/modules/azv07_scriptcore_game
  fi
  if [ -n "$AZSRC" ] && [ -d "$AZSRC" ]; then
    [ -f "$AZSRC/tooltarget.txt" ] || : > "$AZSRC/tooltarget.txt"
    if ! grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
      printf '%s\n' "$PKG" >> "$AZSRC/tooltarget.txt"
    fi
  fi
fi
