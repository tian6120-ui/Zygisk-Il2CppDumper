#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"
TMP="$MODPATH/.bootstrap"
HIST_ARM64="https://nightly.link/tian6120-ui/Zygisk-Il2CppDumper/actions/artifacts/11227499534.zip"
HIST_X64="https://nightly.link/tian6120-ui/Zygisk-Il2CppDumper/actions/artifacts/11227887184.zip"

ui_print "********************************************"
ui_print " Inkvasion Standalone Auto Unlock V2"
ui_print " target: $PKG"
ui_print " host ABI: $ARCH"
ui_print " x64 NativeBridge + arm64 supported"
ui_print "********************************************"

mkdir -p "$MODPATH/zygisk" "$TMP"

find_az_source() {
  for D in     /data/adb/modules/azv07_scriptcore_game     /data/adb/modules_update/azv07_scriptcore_game
  do
    [ -d "$D" ] || continue
    [ -f "$D/libAZCore07_arm64.so" ] || continue
    [ -d "$D/zygisk" ] || continue
    echo "$D"
    return 0
  done

  for BASE in /data/adb/modules /data/adb/modules_update; do
    [ -d "$BASE" ] || continue
    for D in "$BASE"/*; do
      [ -d "$D" ] || continue
      [ "$D" = "$MODPATH" ] && continue
      [ -f "$D/libAZCore07_arm64.so" ] || continue
      [ -d "$D/zygisk" ] || continue
      echo "$D"
      return 0
    done
  done
  return 1
}

AZSRC="$(find_az_source 2>/dev/null)"
[ -n "$AZSRC" ] && ui_print "- AZ runtime source: $AZSRC"

copy_current_runtime() {
  [ -n "$AZSRC" ] || return 1

  for F in "$AZSRC"/zygisk/*.so; do
    [ -f "$F" ] || continue
    cp -f "$F" "$MODPATH/zygisk/$(basename "$F")" || return 1
  done

  [ -f "$AZSRC/libAZCore07_arm64.so" ] && cp -f "$AZSRC/libAZCore07_arm64.so" "$MODPATH/payload.arm64"
  [ -f "$AZSRC/libAZCore07_arm32.so" ] && cp -f "$AZSRC/libAZCore07_arm32.so" "$MODPATH/payload.arm32"
  [ -f "$AZSRC/libAZCore07_x86_64.so" ] && cp -f "$AZSRC/libAZCore07_x86_64.so" "$MODPATH/payload.x86_64"
  [ -f "$AZSRC/libAZCore07_x86.so" ] && cp -f "$AZSRC/libAZCore07_x86.so" "$MODPATH/payload.x86"

  return 0
}

fetch_zip() {
  URL="$1"
  OUT="$2"
  rm -f "$OUT"
  if command -v curl >/dev/null 2>&1; then
    curl -LfsS "$URL" -o "$OUT" && return 0
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -q -O "$OUT" "$URL" && return 0
  fi
  if command -v busybox >/dev/null 2>&1; then
    busybox wget -q -O "$OUT" "$URL" && return 0
  fi
  return 1
}

unzip_to() {
  ZIP="$1"
  OUT="$2"
  rm -rf "$OUT"
  mkdir -p "$OUT"
  if command -v unzip >/dev/null 2>&1; then
    unzip -oq "$ZIP" -d "$OUT" && return 0
  fi
  if command -v busybox >/dev/null 2>&1; then
    busybox unzip -oq "$ZIP" -d "$OUT" && return 0
  fi
  return 1
}

fallback_arm64() {
  Z="$TMP/AZV07-arm64-v8a.zip"
  D="$TMP/arm64"
  fetch_zip "$HIST_ARM64" "$Z" || return 1
  unzip_to "$Z" "$D" || return 1
  LDR="$(find "$D" -type f -name 'libAZLoader07.so' 2>/dev/null | head -n 1)"
  CORE="$(find "$D" -type f -name 'libAZCore07.so' 2>/dev/null | head -n 1)"
  [ -n "$LDR" ] && cp -f "$LDR" "$MODPATH/zygisk/arm64-v8a.so"
  [ -n "$CORE" ] && cp -f "$CORE" "$MODPATH/payload.arm64"
  [ -f "$MODPATH/payload.arm64" ] || return 1
  return 0
}

fallback_x64() {
  Z="$TMP/AZV07-x86_64.zip"
  D="$TMP/x64"
  fetch_zip "$HIST_X64" "$Z" || return 1
  unzip_to "$Z" "$D" || return 1
  LDR="$(find "$D" -type f -name 'libAZLoader07.so' 2>/dev/null | head -n 1)"
  CORE="$(find "$D" -type f -name 'libAZCore07.so' 2>/dev/null | head -n 1)"
  [ -n "$LDR" ] && cp -f "$LDR" "$MODPATH/zygisk/x86_64.so"
  [ -n "$CORE" ] && cp -f "$CORE" "$MODPATH/payload.x86_64"
  [ -f "$MODPATH/zygisk/x86_64.so" ] || return 1
  return 0
}

copy_current_runtime >/dev/null 2>&1

case "$ARCH" in
  arm64|arm64-v8a|aarch64)
    if [ ! -f "$MODPATH/zygisk/arm64-v8a.so" ] || [ ! -f "$MODPATH/payload.arm64" ]; then
      ui_print "- Filling missing arm64 runtime from verified artifact"
      fallback_arm64 || abort "Unable to obtain arm64 Loader/Core runtime"
    fi
    ;;
  x64|x86_64)
    if [ ! -f "$MODPATH/zygisk/x86_64.so" ]; then
      ui_print "- Filling missing x86_64 host Loader from verified artifact"
      fallback_x64 || abort "Unable to obtain x86_64 Loader runtime"
    fi
    if [ ! -f "$MODPATH/payload.arm64" ]; then
      ui_print "- Filling arm64 guest Core for NativeBridge/Houdini"
      fallback_arm64 || abort "Unable to obtain arm64 guest Core runtime"
    fi
    ;;
  *)
    abort "Unsupported host ABI: $ARCH (V2 supports x64 and arm64)"
    ;;
esac

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"

if [ -n "$AZSRC" ] && [ -f "$AZSRC/tooltarget.txt" ]; then
  printf '%s\n' "$AZSRC" > "$MODPATH/az_source_path.txt"
  if grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
    cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
    awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$TMP/tooltarget.new"
    cat "$TMP/tooltarget.new" > "$AZSRC/tooltarget.txt"
    : > "$MODPATH/.az_target_removed"
    ui_print "- Removed Inkvasion only from main AZ target list"
  fi
fi

for P in "$MODPATH"/payload.*; do
  [ -f "$P" ] || continue
  OFF="$(grep -aob -m1 'AZ_TRANSLATED_GUEST' "$P" 2>/dev/null | cut -d: -f1)"
  case "$OFF" in
    ''|*[!0-9]*) ;;
    *) printf 'PATH\000' | dd of="$P" bs=1 seek="$OFF" conv=notrunc 2>/dev/null ;;
  esac
done
ui_print "- AZ UI suppressed; ScriptCore kept"

chmod 0755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH"/payload.* 2>/dev/null
chmod 0644 "$MODPATH"/zygisk/*.so 2>/dev/null

case "$ARCH" in
  x64|x86_64)
    [ -f "$MODPATH/zygisk/x86_64.so" ] || abort "x86_64 Zygisk loader missing after install"
    [ -f "$MODPATH/payload.arm64" ] || abort "arm64 guest payload missing after install"
    ui_print "- Runtime ready: x86_64 host Loader + arm64 guest Core"
    ;;
  *)
    [ -f "$MODPATH/zygisk/arm64-v8a.so" ] || abort "arm64 Zygisk loader missing after install"
    [ -f "$MODPATH/payload.arm64" ] || abort "arm64 payload missing after install"
    ui_print "- Runtime ready: native arm64 Loader + Core"
    ;;
esac

rm -rf "$TMP"

ui_print "- Install complete"
ui_print "- Reboot required"
ui_print "- No manual Lua run is required"
