#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"
SCRIPT="$MODDIR/inkvasion_autorun.lua"
LOG="$MODDIR/inkvasion_service.log"
LAST_PID=""

logi() {
  echo "$(date '+%F %T') $*" >> "$LOG"
}

find_base() {
  for B in /data/user/*/"$PKG" /data/data/"$PKG"; do
    [ -d "$B" ] || continue
    echo "$B"
    return 0
  done
  return 1
}

trigger_process() {
  PID="$1"
  BASE=""
  N=0
  while [ "$N" -lt 120 ]; do
    [ ! -d "/proc/$PID" ] && return
    BASE="$(find_base 2>/dev/null)"
    [ -n "$BASE" ] && break
    sleep 1
    N=$((N+1))
  done
  [ -n "$BASE" ] || { logi "NO APP DATA pid=$PID"; return; }

  ROOT="$BASE/files/AZTool"
  UIDN="$(stat -c '%u' "$BASE" 2>/dev/null)"
  GIDN="$(stat -c '%g' "$BASE" 2>/dev/null)"

  N=0
  while [ "$N" -lt 120 ]; do
    [ ! -d "/proc/$PID" ] && return
    [ -f "$ROOT/agent.ready" ] && break
    sleep 1
    N=$((N+1))
  done

  if [ ! -f "$ROOT/agent.ready" ]; then
    logi "AGENT TIMEOUT pid=$PID root=$ROOT"
    return
  fi

  logi "AGENT READY pid=$PID"
  sleep 8
  [ ! -d "/proc/$PID" ] && return

  cp -f "$SCRIPT" "$ROOT/inkvasion_autorun.lua" || { logi "COPY SCRIPT FAILED pid=$PID"; return; }
  [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/inkvasion_autorun.lua" 2>/dev/null
  chmod 600 "$ROOT/inkvasion_autorun.lua" 2>/dev/null

  ATTEMPT=1
  while [ "$ATTEMPT" -le 5 ]; do
    [ ! -d "/proc/$PID" ] && return
    rm -f "$ROOT/script.status"
    printf '%s\n' "inkvasion_autorun.lua" > "$ROOT/script.req"
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/script.req" 2>/dev/null
    chmod 600 "$ROOT/script.req" 2>/dev/null
    logi "TRIGGER pid=$PID attempt=$ATTEMPT"

    T=0
    while [ "$T" -lt 90 ]; do
      [ ! -d "/proc/$PID" ] && return
      if [ -f "$ROOT/script.status" ]; then
        STATE="$(sed -n 's/^state=//p' "$ROOT/script.status" 2>/dev/null | head -n 1)"
        case "$STATE" in
          DONE) logi "PASS pid=$PID attempt=$ATTEMPT"; return ;;
          ERROR|STOPPED) logi "RETRY pid=$PID attempt=$ATTEMPT state=$STATE"; break ;;
        esac
      fi
      sleep 1
      T=$((T+1))
    done

    ATTEMPT=$((ATTEMPT+1))
    sleep 8
  done

  logi "FAILED pid=$PID after retries"
}

: > "$LOG"
logi "SERVICE START"
while true; do
  PID="$(pidof "$PKG" 2>/dev/null | awk '{print $1}')"
  if [ -n "$PID" ]; then
    if [ "$PID" != "$LAST_PID" ]; then
      LAST_PID="$PID"
      logi "NEW PID $PID"
      trigger_process "$PID" &
    fi
  else
    LAST_PID=""
  fi
  sleep 2
done
