Inkvasion Standalone Auto Unlock V2

Target:
  com.chillyroom.inkvasion.gp

Supported host environments:
  - native arm64 Android
  - x86_64/x64 emulator running the arm64 game through NativeBridge/Houdini/NDK translation

V2 fix:
  V1 incorrectly rejected x64 at install time.
  V2 copies the host Zygisk loader matching the device ABI and keeps payload.arm64 for the translated guest.
  It reuses the same NativeBridge route already used by AZ ScriptCore V0.7.

Runtime source:
  1. Prefer the currently installed AZ/HF7 runtime.
  2. If missing, use verified historical GitHub Actions artifacts.

Game logic:
  The V1 7691-byte Inkvasion autorun Lua is preserved unchanged.
  It dynamically reads Hero/Fight/Building masters, skips existing content,
  adds only missing entries, and exits after verification.
  No HTTP/store/IAP/currency/server ownership writes.

Double-injection prevention:
  Inkvasion is removed only from the original AZ tooltarget list while this module is installed.
  uninstall.sh restores it when this standalone module is removed.

Logs:
  /data/adb/modules/inkvasion_standalone_autounlock/inkvasion_service.log
  /data/user/0/com.chillyroom.inkvasion.gp/files/AZTool/script.out
  /data/user/0/com.chillyroom.inkvasion.gp/files/AZTool/script.status
