#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"
TMP="$MODPATH/.install_tmp"

ui_print "********************************************"
ui_print " Inkvasion Standalone Auto Unlock V3"
ui_print " OFFLINE installer - no network"
ui_print " target: $PKG"
ui_print " host ABI: $ARCH"
ui_print "********************************************"

rm -rf "$MODPATH/zygisk" "$TMP"
rm -f "$MODPATH"/payload.* "$MODPATH"/hostui.*
mkdir -p "$MODPATH/zygisk" "$TMP"

case "$ARCH" in
  x64|x86_64|arm64|arm64-v8a|aarch64) ;;
  *) abort "Unsupported host ABI: $ARCH (supported: x64, arm64)" ;;
esac

find_az_source() {
  for D in     /data/adb/modules/azv07_scriptcore_game     /data/adb/modules_update/azv07_scriptcore_game
  do
    [ -d "$D" ] || continue
    if [ -d "$D/zygisk" ] && { [ -f "$D/libAZCore07_arm64.so" ] || [ -f "$D/payload.arm64" ]; }; then
      echo "$D"; return 0
    fi
  done

  for BASE in /data/adb/modules /data/adb/modules_update; do
    [ -d "$BASE" ] || continue
    for D in "$BASE"/*; do
      [ -d "$D" ] || continue
      [ "$D" = "$MODPATH" ] && continue
      [ -d "$D/zygisk" ] || continue
      if [ -f "$D/libAZCore07_arm64.so" ] || [ -f "$D/payload.arm64" ]; then
        echo "$D"; return 0
      fi
    done
  done
  return 1
}

AZSRC="$(find_az_source 2>/dev/null)"
[ -n "$AZSRC" ] || abort "AZ/HF7 runtime not found. Keep your working AZ module installed, then flash V3 again."

ui_print "- Found AZ runtime:"
ui_print "  $AZSRC"

copy_first() {
  DST="$1"; shift
  for SRC in "$@"; do
    [ -f "$SRC" ] || continue
    cp -f "$SRC" "$DST" && return 0
  done
  return 1
}

# Copy all standard Zygisk ABI loaders that actually exist.
for F in "$AZSRC"/zygisk/*.so; do
  [ -f "$F" ] || continue
  cp -f "$F" "$MODPATH/zygisk/$(basename "$F")" || abort "Failed copying $(basename "$F")"
done

# arm64 guest/native Core.
copy_first "$MODPATH/payload.arm64"   "$AZSRC/libAZCore07_arm64.so"   "$AZSRC/payload.arm64"   "$AZSRC/lib/arm64-v8a/libAZCore07.so"   "$AZSRC/arm64-v8a/libAZCore07.so"   || abort "AZ arm64 Core not found inside $AZSRC"

# Optional other native cores.
copy_first "$MODPATH/payload.x86_64"   "$AZSRC/libAZCore07_x86_64.so"   "$AZSRC/payload.x86_64"   "$AZSRC/lib/x86_64/libAZCore07.so"   "$AZSRC/x86_64/libAZCore07.so" >/dev/null 2>&1

copy_first "$MODPATH/payload.arm32"   "$AZSRC/libAZCore07_arm32.so"   "$AZSRC/payload.arm32" >/dev/null 2>&1

copy_first "$MODPATH/payload.x86"   "$AZSRC/libAZCore07_x86.so"   "$AZSRC/payload.x86" >/dev/null 2>&1

# Optional translated-host UI bridge. Core can still auto-start without it.
copy_first "$MODPATH/hostui.x86_64"   "$AZSRC/hostui.x86_64"   "$AZSRC/libAZHostUI07_x86_64.so"   "$AZSRC/lib/x86_64/libAZHostUI07.so" >/dev/null 2>&1

# If the standard x86_64 loader name is absent, search only this AZ module locally.
if [ "$ARCH" = "x64" ] || [ "$ARCH" = "x86_64" ]; then
  if [ ! -f "$MODPATH/zygisk/x86_64.so" ]; then
    CAND="$(find "$AZSRC" -type f \( -path '*/zygisk/x86_64.so' -o -name 'libAZLoader07_x86_64.so' \) 2>/dev/null | head -n 1)"
    [ -n "$CAND" ] && cp -f "$CAND" "$MODPATH/zygisk/x86_64.so"
  fi
  [ -f "$MODPATH/zygisk/x86_64.so" ] || abort "x86_64 AZ Zygisk Loader not found in $AZSRC"
  [ -f "$MODPATH/payload.arm64" ] || abort "arm64 guest Core missing"
  ui_print "- Runtime ready: x86_64 Loader + arm64 guest Core"
else
  if [ ! -f "$MODPATH/zygisk/arm64-v8a.so" ]; then
    CAND="$(find "$AZSRC" -type f \( -path '*/zygisk/arm64-v8a.so' -o -name 'libAZLoader07_arm64.so' \) 2>/dev/null | head -n 1)"
    [ -n "$CAND" ] && cp -f "$CAND" "$MODPATH/zygisk/arm64-v8a.so"
  fi
  [ -f "$MODPATH/zygisk/arm64-v8a.so" ] || abort "arm64 AZ Zygisk Loader not found in $AZSRC"
  [ -f "$MODPATH/payload.arm64" ] || abort "arm64 Core missing"
  ui_print "- Runtime ready: native arm64 Loader + Core"
fi

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"
printf '%s\n' "$AZSRC" > "$MODPATH/az_source_path.txt"

# Prevent two AZ-style loaders from targeting Inkvasion at the same time.
if [ -f "$AZSRC/tooltarget.txt" ] && grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
  cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
  awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$TMP/tooltarget.new"
  cat "$TMP/tooltarget.new" > "$AZSRC/tooltarget.txt"
  : > "$MODPATH/.az_target_removed"
  ui_print "- Removed Inkvasion from main AZ target list only"
fi

# Suppress copied AZ floating UI while preserving ScriptCore.
for P in "$MODPATH"/payload.*; do
  [ -f "$P" ] || continue
  OFF="$(grep -aob -m1 'AZ_TRANSLATED_GUEST' "$P" 2>/dev/null | cut -d: -f1)"
  case "$OFF" in
    ''|*[!0-9]*) ;;
    *) printf 'PATH\000' | dd of="$P" bs=1 seek="$OFF" conv=notrunc 2>/dev/null ;;
  esac
done

chmod 0755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH"/payload.* "$MODPATH"/hostui.* 2>/dev/null
chmod 0644 "$MODPATH"/zygisk/*.so 2>/dev/null
rm -rf "$TMP"

ui_print "- Offline runtime copy complete"
ui_print "- No downloads were used"
ui_print "- Reboot required"
ui_print "- Inkvasion will auto-supplement after launch"
