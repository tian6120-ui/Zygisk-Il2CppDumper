Inkvasion Standalone Auto Unlock V3

V3 fixes the V2 installer hang.
V2 could wait forever while downloading a missing x86_64 runtime.
V3 performs ZERO installer network access.

At flash time V3 copies the runtime from the already-installed working AZ/HF7 module:
- x64 emulator: x86_64 Zygisk Loader + arm64 guest Core
- arm64 phone: arm64 Zygisk Loader + arm64 Core

After copying, this standalone module owns its runtime copy.
The original Inkvasion V1 autorun Lua is preserved byte-for-byte.

If required AZ runtime files cannot be found, installation aborts immediately with a concrete error instead of downloading/hanging.

Target: com.chillyroom.inkvasion.gp
