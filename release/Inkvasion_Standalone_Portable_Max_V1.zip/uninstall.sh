#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"
if [ -f "$MODDIR/.az_target_removed" ]; then
  AZSRC="$(cat "$MODDIR/az_source_path.txt" 2>/dev/null)"
  if [ -n "$AZSRC" ] && [ -d "$AZSRC" ]; then
    [ -f "$AZSRC/tooltarget.txt" ] || : > "$AZSRC/tooltarget.txt"
    grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null || printf '%s\n' "$PKG" >> "$AZSRC/tooltarget.txt"
  fi
fi
