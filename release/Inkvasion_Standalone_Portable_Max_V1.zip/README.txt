Inkvasion Portable Auto Unlock + Max V2

SELF-CONTAINED. No AZ/HF7 installation is required.

Bundled runtime:
- arm64 AZ ScriptCore V0.7 Core
- arm64 Zygisk Loader
- x86_64 Zygisk Loader
No HostUI is bundled; this is background-only.

Supported:
- native arm64 phone/tablet
- x86_64 emulator/host running arm64 Inkvasion through NativeBridge/Houdini/NDK translation

Every new Inkvasion process:
- waits for runner READY
- writes last.lua
- writes "last.lua" into script.req (verified historical runner protocol)
- dynamically adds missing heroes/fight/build cards
- maxes every card using GetShowingMaxLevel() + SetLevelByShowingLevel(max)
- verifies GetShowingLevel()==max for every card
- exits; no resident Lua watchdog

No HTTP/store/IAP/currency/server ownership writes.
