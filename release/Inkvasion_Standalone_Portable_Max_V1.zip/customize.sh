#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"

ui_print "********************************************"
ui_print " Inkvasion Portable Auto Unlock + Max V2"
ui_print " SELF-CONTAINED | OFFLINE"
ui_print " target: $PKG"
ui_print " host ABI: $ARCH"
ui_print "********************************************"

case "$ARCH" in
  arm64|arm64-v8a|aarch64|x64|x86_64) ;;
  *) abort "Unsupported host ABI: $ARCH (supported: arm64/x86_64)" ;;
esac

[ -f "$MODPATH/payload.arm64" ] || abort "Bundled arm64 Core missing"
[ -f "$MODPATH/zygisk/arm64-v8a.so" ] || abort "Bundled arm64 Loader missing"
[ -f "$MODPATH/zygisk/x86_64.so" ] || abort "Bundled x86_64 Loader missing"

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"

# If the full AZ module is installed too, remove only Inkvasion from its target list.
AZSRC=""
for D in /data/adb/modules/azv07_scriptcore_game /data/adb/modules_update/azv07_scriptcore_game; do
  [ -d "$D" ] || continue
  AZSRC="$D"; break
done
if [ -n "$AZSRC" ] && [ -f "$AZSRC/tooltarget.txt" ] && grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
  printf '%s\n' "$AZSRC" > "$MODPATH/az_source_path.txt"
  cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
  awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$MODPATH/.tooltarget.new"
  cat "$MODPATH/.tooltarget.new" > "$AZSRC/tooltarget.txt"
  rm -f "$MODPATH/.tooltarget.new"
  : > "$MODPATH/.az_target_removed"
  ui_print "- Removed Inkvasion only from full AZ target list"
fi

chmod 0755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH/payload.arm64" "$MODPATH"/zygisk/*.so

ui_print "- Bundled runtime verified"
ui_print "- arm64 phones: supported"
ui_print "- x86_64 host + arm64 game: supported"
ui_print "- No existing AZ/HF7 installation required"
ui_print "- Reboot required"
