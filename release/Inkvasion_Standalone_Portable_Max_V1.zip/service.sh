#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"
SCRIPT="$MODDIR/inkvasion_autorun.lua"
LOG="$MODDIR/inkvasion_service.log"
LAST_PID=""

logi(){ echo "$(date '+%F %T') $*" >> "$LOG"; }
find_base(){
  for B in /data/user/*/"$PKG" /data/data/"$PKG"; do
    [ -d "$B" ] || continue
    echo "$B"; return 0
  done
  return 1
}
state_of(){
  [ -f "$1/script.status" ] || return
  sed -n 's/^state=//p' "$1/script.status" 2>/dev/null | head -n 1
}
pass_out(){
  [ -f "$1/script.out" ] || return 1
  tail -n 240 "$1/script.out" 2>/dev/null | grep -Fq "[INKVASION AUTO V1] RESULT | PASS | ALL HERO + FIGHT + BUILD + MAX LEVEL"
}
fatal_out(){
  [ -f "$1/script.out" ] || return 1
  tail -n 240 "$1/script.out" 2>/dev/null | grep -Fq "[INKVASION AUTO V1] FATAL |"
}

trigger_process(){
  PID="$1"
  LOCK="$MODDIR/.trigger_$PID.lock"
  mkdir "$LOCK" 2>/dev/null || return

  BASE=""
  N=0
  while [ "$N" -lt 120 ]; do
    [ ! -d "/proc/$PID" ] && { rmdir "$LOCK" 2>/dev/null; return; }
    BASE="$(find_base 2>/dev/null)"
    [ -n "$BASE" ] && break
    sleep 1; N=$((N+1))
  done
  if [ -z "$BASE" ]; then logi "NO APP DATA pid=$PID"; rmdir "$LOCK" 2>/dev/null; return; fi

  ROOT="$BASE/files/AZTool"
  UIDN="$(stat -c '%u' "$BASE" 2>/dev/null)"
  GIDN="$(stat -c '%g' "$BASE" 2>/dev/null)"

  sleep 2
  READY=0
  N=0
  while [ "$N" -lt 150 ]; do
    [ ! -d "/proc/$PID" ] && { rmdir "$LOCK" 2>/dev/null; return; }
    STATE="$(state_of "$ROOT")"
    if [ "$STATE" = "READY" ]; then READY=1; break; fi
    sleep 1; N=$((N+1))
  done
  if [ "$READY" -ne 1 ]; then
    logi "RUNNER READY TIMEOUT pid=$PID state=$(state_of "$ROOT")"
    rmdir "$LOCK" 2>/dev/null
    return
  fi

  logi "RUNNER READY pid=$PID"
  sleep 8

  ATTEMPT=1
  while [ "$ATTEMPT" -le 5 ]; do
    [ ! -d "/proc/$PID" ] && break

    cp -f "$SCRIPT" "$ROOT/last.lua" || { logi "COPY FAILED pid=$PID"; break; }
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/last.lua" 2>/dev/null
    chmod 600 "$ROOT/last.lua" 2>/dev/null
    rm -f "$ROOT/stop.req"
    printf '%s\n' "last.lua" > "$ROOT/script.req"
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/script.req" 2>/dev/null
    chmod 600 "$ROOT/script.req" 2>/dev/null

    logi "TRIGGER pid=$PID attempt=$ATTEMPT | script.req=last.lua"

    T=0
    while [ "$T" -lt 150 ]; do
      [ ! -d "/proc/$PID" ] && break 2
      if pass_out "$ROOT"; then
        logi "PASS pid=$PID attempt=$ATTEMPT"
        rmdir "$LOCK" 2>/dev/null
        return
      fi
      if fatal_out "$ROOT"; then
        LINE="$(tail -n 240 "$ROOT/script.out" 2>/dev/null | grep -F "[INKVASION AUTO V1] FATAL |" | tail -n 1)"
        logi "SCRIPT FATAL pid=$PID attempt=$ATTEMPT | $LINE"
        break
      fi
      STATE="$(state_of "$ROOT")"
      case "$STATE" in
        ERROR|STOPPED)
          MSG="$(sed -n 's/^message=//p' "$ROOT/script.status" 2>/dev/null | head -n 1)"
          logi "RUNNER $STATE pid=$PID attempt=$ATTEMPT msg=$MSG"
          break ;;
        DONE)
          logi "DONE WITHOUT PASS pid=$PID attempt=$ATTEMPT"
          break ;;
      esac
      sleep 1; T=$((T+1))
    done
    ATTEMPT=$((ATTEMPT+1))
    [ "$ATTEMPT" -le 5 ] && sleep 10
  done

  logi "FAILED pid=$PID after retries"
  rmdir "$LOCK" 2>/dev/null
}

: > "$LOG"
rm -rf "$MODDIR"/.trigger_*.lock 2>/dev/null
logi "SERVICE START | self-contained | trigger=script.req:last.lua"

while true; do
  PID="$(pidof "$PKG" 2>/dev/null | awk '{print $1}')"
  if [ -n "$PID" ]; then
    if [ "$PID" != "$LAST_PID" ]; then
      LAST_PID="$PID"
      logi "NEW PID $PID"
      trigger_process "$PID" &
    fi
  else
    LAST_PID=""
  fi
  sleep 2
done
