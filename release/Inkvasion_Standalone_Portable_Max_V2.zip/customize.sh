#!/system/bin/sh
SKIPUNZIP=0
PKG="com.chillyroom.inkvasion.gp"
BASE="https://raw.githubusercontent.com/tian6120-ui/Zygisk-Il2CppDumper/inkvasion-portable-max-v2/runtime"
TMP="$MODPATH/.runtime_fetch"
RZIP="$TMP/runtime.zip"
PARTS=7
EXPECTED=7222536

ui_print "********************************************"
ui_print " Inkvasion Portable Auto Unlock Max V2.2"
ui_print " EXACT HF7 runtime bootstrap"
ui_print " ARM64 + x64-host/ARM64-guest"
ui_print "********************************************"

rm -rf "$TMP"
mkdir -p "$TMP"

fetch_one() {
  URL="$1"
  OUT="$2"
  rm -f "$OUT"

  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --silent --show-error --connect-timeout 5 --max-time 30 --retry 2 --retry-delay 1 "$URL" -o "$OUT" && return 0
  fi

  if command -v wget >/dev/null 2>&1; then
    wget -T 20 -t 2 -q -O "$OUT" "$URL" && return 0
  fi

  if command -v busybox >/dev/null 2>&1; then
    busybox wget -T 20 -t 2 -q -O "$OUT" "$URL" && return 0
  fi

  return 1
}

I=0
while [ "$I" -lt "$PARTS" ]; do
  NN="$(printf '%02d' "$I")"
  ui_print "- HF7 runtime part $((I+1))/$PARTS"
  fetch_one "$BASE/runtime.zip.part$NN" "$TMP/part$NN" || abort "HF7 runtime download failed at part $NN"
  I=$((I+1))
done

: > "$RZIP"
I=0
while [ "$I" -lt "$PARTS" ]; do
  NN="$(printf '%02d' "$I")"
  cat "$TMP/part$NN" >> "$RZIP" || abort "HF7 runtime assemble failed at part $NN"
  I=$((I+1))
done

ACTUAL="$(wc -c < "$RZIP" 2>/dev/null | tr -d ' ')"
[ "$ACTUAL" = "$EXPECTED" ] || abort "HF7 runtime size mismatch: $ACTUAL / $EXPECTED"

if command -v unzip >/dev/null 2>&1; then
  unzip -tq "$RZIP" >/dev/null 2>&1 || abort "HF7 runtime ZIP CRC test failed"
  unzip -oq "$RZIP" -d "$MODPATH" || abort "HF7 runtime extract failed"
elif command -v busybox >/dev/null 2>&1; then
  busybox unzip -t "$RZIP" >/dev/null 2>&1 || abort "HF7 runtime ZIP CRC test failed"
  busybox unzip -oq "$RZIP" -d "$MODPATH" || abort "HF7 runtime extract failed"
else
  abort "No unzip implementation available"
fi

[ -f "$MODPATH/libAZGlass4_arm64.so" ] || abort "HF7 arm64 payload missing"
[ -f "$MODPATH/zygisk/arm64-v8a.so" ] || abort "HF7 arm64 Zygisk loader missing"
[ -f "$MODPATH/zygisk/x86_64.so" ] || abort "HF7 x86_64 Zygisk loader missing"

printf '%s\n' "$PKG" > "$MODPATH/tooltarget.txt"

for AZSRC in   /data/adb/modules/azv07_scriptcore_game   /data/adb/modules_update/azv07_scriptcore_game   /data/adb/ksu/modules/azv07_scriptcore_game   /data/adb/ksu/modules_update/azv07_scriptcore_game
do
  [ -f "$AZSRC/tooltarget.txt" ] || continue
  if grep -Fxq "$PKG" "$AZSRC/tooltarget.txt" 2>/dev/null; then
    printf '%s\n' "$AZSRC" > "$MODPATH/az_source_path.txt"
    cp -f "$AZSRC/tooltarget.txt" "$MODPATH/original_az_tooltarget.bak"
    awk -v p="$PKG" '$0 != p { print }' "$AZSRC/tooltarget.txt" > "$TMP/target.new"
    cat "$TMP/target.new" > "$AZSRC/tooltarget.txt"
    : > "$MODPATH/.az_target_removed"
    ui_print "- Existing AZ: Inkvasion target disabled to prevent double injection"
    break
  fi
done

chmod 0755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop" "$MODPATH/tooltarget.txt" "$MODPATH/inkvasion_autorun.lua"
chmod 0644 "$MODPATH/libAZGlass4_arm64.so" "$MODPATH/embedded_core_r8.so" "$MODPATH"/zygisk/*.so "$MODPATH/scripts/AppLabelHelper.dex" 2>/dev/null

rm -rf "$TMP"

ui_print "- Exact HF7 runtime installed locally"
ui_print "- No existing AZ module is required after install"
ui_print "- Reboot required"
