#!/system/bin/sh
MODDIR="$(dirname "$0")"
PKG="com.chillyroom.inkvasion.gp"
SCRIPT="$MODDIR/inkvasion_autorun.lua"
LOG="$MODDIR/inkvasion_service.log"
LAST_PID=""

logi(){ echo "$(date '+%F %T') $*" >> "$LOG"; }

find_base(){
  for B in /data/user/*/"$PKG" /data/data/"$PKG"; do
    [ -d "$B" ] || continue
    echo "$B"
    return 0
  done
  return 1
}

runner_ready(){
  ROOT="$1"

  [ -f "$ROOT/agent.ready" ] && return 0

  [ -f "$ROOT/script.status" ] || return 1
  STATE="$(sed -n 's/^state=//p' "$ROOT/script.status" 2>/dev/null | head -n 1)"
  [ "$STATE" = "READY" ] && return 0

  return 1
}

has_pass(){
  ROOT="$1"
  [ -f "$ROOT/script.out" ] || return 1
  tail -n 220 "$ROOT/script.out" 2>/dev/null | grep -Fq "[INKVASION PORTABLE MAX V2] RESULT | PASS | ALL HERO + FIGHT + BUILD + MAX LEVEL"
}

fatal_line(){
  ROOT="$1"
  [ -f "$ROOT/script.out" ] || return 0
  tail -n 220 "$ROOT/script.out" 2>/dev/null | grep -F "[INKVASION PORTABLE MAX V2] FATAL |" | tail -n 1
}

trigger_process(){
  PID="$1"
  BASE=""
  N=0

  while [ "$N" -lt 120 ]; do
    [ ! -d "/proc/$PID" ] && return
    BASE="$(find_base 2>/dev/null)"
    [ -n "$BASE" ] && break
    sleep 1
    N=$((N+1))
  done

  [ -n "$BASE" ] || {
    logi "NO APP DATA pid=$PID"
    return
  }

  ROOT="$BASE/files/AZTool"
  UIDN="$(stat -c '%u' "$BASE" 2>/dev/null)"
  GIDN="$(stat -c '%g' "$BASE" 2>/dev/null)"

  N=0
  while [ "$N" -lt 150 ]; do
    [ ! -d "/proc/$PID" ] && return
    runner_ready "$ROOT" && break
    sleep 1
    N=$((N+1))
  done

  runner_ready "$ROOT" || {
    logi "RUNNER READY TIMEOUT pid=$PID root=$ROOT"
    return
  }

  logi "RUNNER READY pid=$PID root=$ROOT"

  # Do not touch Inkvasion during INIT_DYNAMIC_CONFIG/login.
  sleep 20
  [ ! -d "/proc/$PID" ] && return

  ATTEMPT=1
  while [ "$ATTEMPT" -le 12 ]; do
    [ ! -d "/proc/$PID" ] && return

    cp -f "$SCRIPT" "$ROOT/last.lua" || {
      logi "COPY last.lua FAILED pid=$PID attempt=$ATTEMPT"
      return
    }

    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/last.lua" 2>/dev/null
    chmod 600 "$ROOT/last.lua" 2>/dev/null

    : > "$ROOT/script.out" 2>/dev/null
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/script.out" 2>/dev/null

    rm -f "$ROOT/stop.req"
    : > "$ROOT/script.req"
    [ -n "$UIDN" ] && chown "$UIDN:$GIDN" "$ROOT/script.req" 2>/dev/null
    chmod 600 "$ROOT/script.req" 2>/dev/null

    logi "TRIGGER pid=$PID attempt=$ATTEMPT"

    T=0
    CONSUMED=0
    while [ "$T" -lt 120 ]; do
      [ ! -d "/proc/$PID" ] && return

      if [ "$CONSUMED" -eq 0 ] && [ ! -e "$ROOT/script.req" ]; then
        CONSUMED=1
        logi "REQ CONSUMED pid=$PID attempt=$ATTEMPT"
      fi

      if has_pass "$ROOT"; then
        logi "PASS pid=$PID attempt=$ATTEMPT"
        return
      fi

      FATAL="$(fatal_line "$ROOT")"
      if [ -n "$FATAL" ]; then
        logi "SCRIPT FATAL pid=$PID attempt=$ATTEMPT | $FATAL"
        break
      fi

      if [ "$T" -ge 35 ] && [ -e "$ROOT/script.req" ]; then
        logi "REQ NOT CONSUMED pid=$PID attempt=$ATTEMPT"
        rm -f "$ROOT/script.req"
        break
      fi

      sleep 1
      T=$((T+1))
    done

    ATTEMPT=$((ATTEMPT+1))
    [ "$ATTEMPT" -le 12 ] && sleep 12
  done

  logi "FAILED pid=$PID after retries"
}

: > "$LOG"
logi "SERVICE START | exact-HF7 portable | max=true"

while true; do
  PID="$(pidof "$PKG" 2>/dev/null | awk '{print $1}')"

  if [ -n "$PID" ]; then
    if [ "$PID" != "$LAST_PID" ]; then
      LAST_PID="$PID"
      logi "NEW PID $PID"
      trigger_process "$PID" &
    fi
  else
    LAST_PID=""
  fi

  sleep 2
done
