Inkvasion Portable Auto Unlock Max V2.2

Install/runtime
- exact runtime source: AZ_R8_TOOLS_LIVEINPUT_HF7_ARM64 (1).zip
- installer downloads 7 bounded-size chunks with hard timeout/retry
- checks total runtime size and ZIP CRC before extraction
- after installation the runtime is fully local
- target device does not need an existing AZ module
- supports native ARM64 Android and x86_64 host + ARM64 guest/Houdini

Automatic behavior each new Inkvasion process
- waits for HF7 runner READY
- then waits another 20 seconds so the game's own INIT_DYNAMIC_CONFIG/login/UserAssets can finish
- dynamically scans current Hero/FightCard/BuildingCard masters
- adds only missing heroes/cards
- then maxes ALL current cards through:
  CardItemData.GetShowingMaxLevel()
  CardItemData.SetLevelByShowingLevel(max)
- verifies ownership and max level
- Lua exits; there is no Lua watchdog loop

Scope
- client-local automatic reapply
- no server ownership writes
- no store/IAP/currency calls

Target
com.chillyroom.inkvasion.gp
