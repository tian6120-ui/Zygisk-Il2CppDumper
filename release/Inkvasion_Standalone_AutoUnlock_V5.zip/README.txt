Inkvasion Standalone Auto Unlock V5

V5 aligns with the actual HF7 loader protocol.
Verified HF7 behavior on x86_64 host + arm64 game:
  selected_payload=libAZGlass4_arm64.so

Therefore this module preserves the HF7 payload filenames instead of looking for the obsolete libAZCore07_arm64.so/payload.arm64 layout.

Install-time source:
  id=azv07_scriptcore_game
Copies:
  zygisk/*.so
  libAZGlass4_arm64.so
  optional other libAZGlass4 ABI payloads

No network access.
Target: com.chillyroom.inkvasion.gp
